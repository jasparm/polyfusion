/*
File containing the code for our 2d canvas.
*/
function setup() {
    let canvas = createCanvas(400, 400);
    canvas.parent('canvas-container');
}
function draw() {
    background(220);
}